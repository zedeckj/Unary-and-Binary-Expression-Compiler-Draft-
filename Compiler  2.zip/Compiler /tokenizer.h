//
// Created by Jordan on 6/23/22.
//

#ifndef COMPILER_TOKENIZER_H
#define COMPILER_TOKENIZER_H

char ** tokenize(char * str_int, int * token_count);

#endif //COMPILER_TOKENIZER_H
