//
// Created by Jordan on 6/23/22.
// Breaks down a String into non empty parts, plus special characters
//

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>


#define SPECIAL_COUNT 13
char special[SPECIAL_COUNT] = {'(',')','=', '+', '/', '*', '#', '%', ';', ':', '|', '&'}; //'0', '1', '2', '3','4','5','6','7','8', '9'};
int special_index(char c) {
    for (int i = 0; i < SPECIAL_COUNT; i++) {
        if (c == special[i]) return i;
    }
    return -1;
}

int isempty(char c) {
    return isspace(c) || c == '\0';
}


char ** tokenize(char * str_in, int * token_count) {
    *token_count = 0;
    int max_count = 50;
    char ** tokens = malloc(sizeof(char *) * max_count);
    printf("tokens malloc'd\n");
    int len = strlen(str_in);
    char empty[100] = {'\0'};
    char temp_token[100] = {'\0'};
    for (int j = 0, i = 0; i < len + 1; j++, i++) {
        int si = special_index(str_in[i]);
        if (isempty(str_in[i]) || si > -1) {
            if (j > 0){
                temp_token[j] = '\0';
                tokens[*token_count] = malloc(sizeof(char) * j);
                strncpy(tokens[*token_count], temp_token, j);
                *token_count+=1;
            }
            if (si > -1) {
                j = 0;
                tokens[*token_count] = malloc(sizeof(char));
                tokens[*token_count][0] = str_in[i];
                *token_count+=1;
            }
            j = -1;

        }
        else {
            temp_token[j] = str_in[i];
        }
    }
    *token_count-=1;
    return tokens;
}



