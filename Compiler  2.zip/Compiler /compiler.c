//
// Created by Jordan on 6/29/22.
//

#ifndef COMPILER__COMPILER_C
#define COMPILER__COMPILER_C

//struct instruction * instructs;
//enum type{declare, jump_if, jump, op, label};

#include <stdio.h>
#include "expressionizer.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

struct identifier {
    char * name;
    char * location;
};

struct identifier * ids;
int idi = 0;
FILE * out;


char * getloc(char * str) {
    if (strcmp(str,"%reg") == 0) {
        return "%rax";
    }
    else if (str[0] == '%') {
        return str;
    }
    for (int i = 0; i < idi; i++) {
        if (strcmp(ids[i].name, str) == 0) {
            return ids[i].location;
        }
    }
    printf("Error: identifier %s is not defined\n", str);
    return 0;
}

int op2nn(char * op, int arg1, int arg2) {
    fprintf(out,"\t%s %d, $%d\n", op, arg1, arg2);
    fprintf(out,"\t%s %d, $%d\n", op, arg1, arg2);
    return 0;
}

int op2sn(char * op, char * arg1, int arg2) {
    if (arg1 == 0) return 1;
    fprintf(out,"\t%s %s, $%d\n", op, arg1, arg2);
    return 0;
}

int op2ns(char * op, int arg1, char * arg2) {
    if (arg2 == 0) return 1;
    fprintf(out,"\t%s $%d, %s\n", op, arg1, arg2);
    return 0;
}


int op2ss(char * op, char * arg1, char * arg2) {
    if (arg1 == 0 || arg2 == 0) return 1;
    fprintf(out,"\t%s %s, %s\n", op, arg1, arg2);
    return 0;
}

int op2(char * op, char * arg1, char * arg2) {
    int n1 = number(arg1);
    int n2 = number(arg2);
    if (n1&&n2){
        return op2nn(op, atoi(arg1), atoi(arg2));
    }
    else if (n1) {
        return op2ns(op, atoi(arg1), getloc(arg2));
    }
    else if (n2) {
        return op2sn(op, getloc(arg1), atoi(arg2));
    }
    else {
        return op2ss(op, getloc(arg1), getloc(arg2));
    }
}

int op1(char * op, char * arg1) {
    fprintf(out,"\t%s %s\n", op, getloc(arg1));
    return 0;
}

void println(char * str) {
    fprintf(out,"\t%s\n",str);
}

int check_namefree(char * name) {
    for (int i = 0; i < idi; i++) {
        if (strcmp(name,ids[i].name) == 0) {
            fprintf(out,"Error: Identifier %s already in use.\n", name);
            return 1;
        }
    }
    return 0;
}

int cmpl_op(char * op, char * src, char * dest) {
    switch (op[0]) {
        case '=':
            return op2("mov", src, dest);
        case '+':
            return op2("add", src, dest);
        case '-':
            return op2("sub", src, dest);
        case '*':
            op2("mov", src, "%rax");
            return op1("mulq", dest) || op2("mov", "%rax", dest);
    }
    return 0;
}

int cmp_label(char * label) {
    if (check_namefree(label)) return 1;
    ids[idi].name = malloc(sizeof(char *));
    ids[idi].location = malloc(sizeof(char *));

    strcpy(ids[idi].name, label);
    strcpy(ids[idi].location, label);
    fprintf(out,"\t%s:\n", label);
    idi++;
    return 0;
}

int cmpl_jump(char * label) {
    op1("jmp", label);
    return 0;
}


int cmpl_jump_if(char * label) {
    op2("cmp", "%reg", "0");
    op1("jne", label);
    return 0;
}


int cmpl_declare(char * name) {
    if (check_namefree(name)) return 1;
    static int memo = -8;
    ids[idi].name = malloc(sizeof(char *));
    ids[idi].location = malloc(sizeof(char *));

    strcpy(ids[idi].name, name);
    sprintf(ids[idi].location, "%d(%s)", memo, "%rbp");
    memo -= 8;
    idi++;
    return 0;
}

int cmpl_print_number(char * str) {
    fprintf(out, "%s", "\tlea nout(%rip), %rdi\n");
    if (getloc(str) != 0) fprintf(out, "\tmov %s, %s\n", getloc(str), "%rsi");
    else if (number(str)) op2ns("mov", atoi(str), "%rsi");
    op2ns("mov", 0, "%rax");
    fprintf(out,"\tcall _printf\n");
    return 0;
}

void init_ids() {
    ids = malloc(idcount * sizeof(struct identifier));
}

void read(char * filename) {
    FILE * read = fopen(filename, "r");
    char * str = malloc(sizeof(char) * 100);
    do {
        str = fgets(str, 100, read);
        if (str) printf("%s", str);
    } while (str);
    printf("\n\n");
    free(str);
    fclose(read);

}

void compile() {
    printf("\n");
    init_ids();
    char * filename = "asm.s";
    out = fopen(filename,"w");
    fprintf(out,".data\n\n");
    fprintf(out,".align 16\n\n");
    fprintf(out,"nout:\n");
    fprintf(out, "\t%s", ".asciz \"%d\\n\"\n\n");
    fprintf(out,".text\n\n");
    fprintf(out,".global _main\n\n");
    fprintf(out,"_main:\n");
    op1("push", "%rbp");
    op2("mov", "%rsp", "%rbp");
    op2ns("sub", 16*(idcount - labels), "%rsp");
    for (int i = 0; i < ii; i++) {
        int error;
        switch (instructs[i].type) {
            case print:
                printf("<print>: ");
                error = cmpl_print_number(instructs[i].args[0]);
                break;
            case declare:
                printf("<declare>: ");
                error = cmpl_declare(instructs[i].args[0]);
                break;
            case binary_op:
                printf("<op>: ");
                error = cmpl_op(instructs[i].args[0], instructs[i].args[1], instructs[i].args[2]);
                break;
            case jump:
                printf("<jump>: ");
                error = cmpl_jump(instructs[i].args[0]);
                break;
            case jump_if:
                printf("<jumpif>: ");
                error = cmpl_jump_if(instructs[i].args[1]);
                break;
            case label:
                printf("<label>: ");
                error = cmp_label(instructs[i].args[0]);
                break;
        }
        for (int j = 0; j < instructs[i].argc; j++) {
            printf("%s ", instructs[i].args[j]);
        }
        printf("\n");
        if (error) {
            goto end;
        }
    }
    printf("\n");
    end:
    fprintf(out,"\tleave\n");
    fprintf(out,"\tret\n");
    fclose(out);
    read(filename);
}


#endif //COMPILER__COMPILER_C
