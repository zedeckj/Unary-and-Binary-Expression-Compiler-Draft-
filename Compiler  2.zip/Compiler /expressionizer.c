//
// Created by Jordan on 6/26/22.
//

#include <string.h>
#include <ctype.h>
#include <printf.h>
#include <stdlib.h>
#include "expressionizer.h"

int idcount = 0;
int labels = 0;
int ii = 0;

/*
 *  1) Break token list into list of statements, each statement ends with ;
 *  2)
 *
 *
 *
 *
 *  - <UNDEF_STRING> -> a token that contains letters that has not been defined
 *  - <VAR_STRING> -> a token that contains letters that has been defined as a variable
 *  - <NUMBER> -> a token that contains only numbers and 0 or 1 .
 *  - <VALUE> -> <NUMBER>
 *  - <VALUE> -> <VAR_STRING>
 *  - <ID> -> I64 <UNDEF_STRING>
 *  - <BINARY_OP> -> +
 *  - <BINARY_OP> -> -
 *  - <BINARY_OP> -> /
 *  - <BINARY_OP> -> *
 *  - <ASSIGN_OP> -> =
 *  - <ASSIGN_OP> -> <BINARY_OP>=
 *  - <ASSIGNMENT1> -> <VAR_STRING> <ASSIGN_OP> <VALUE>
 *  - <ASSIGNMENT2> -> <VAR_STRING> <ASSIGN_OP> <VALUE> <BINARY_OP> <VALUE>
 *
 */
#define KEYCOUNT 4
char * keywords[KEYCOUNT] = {"I64", "goto", "if", "puts"};

int isize = 100;



void add_instruction(enum type type, char ** args, int argc) {
    if (ii == 0) {
        instructs = malloc(isize * sizeof(struct instruction));
        isize *= 2;
    }
    else if (ii >= (isize/2)) {
        instructs = realloc(instructs, isize);
    }
    instructs[ii].type = type;
    instructs[ii].args = malloc(sizeof(char *) * argc);
    instructs[ii].argc = argc;
    memcpy(instructs[ii].args,args,argc);
    char * print_type;
    switch (type) {
        case print:
            print_type = "print";
            break;
        case label:
            print_type = "label";
            idcount++;
            labels++;
            break;
        case declare:
            print_type = "declare";
            idcount++;
            break;
        case jump_if:
            print_type = "goto_if";
            break;
        case jump:
            print_type = "goto";
            break;
        case binary_op:
            print_type = "binary_op";
            break;
    }
   //printf("!!!<%s>:", print_type);
    for (int n = 0 ; n < argc; n++) {
        instructs[ii].args[n] = args[n];
        //printf(" %s", args[n]);
    }
   //printf("\n");
    ii++;
}

void printt(char ** tokens, int count) {
    for (int i = 0; i < count; i++) {
        printf("%s ", tokens[i]);
    }
    printf("\n");
}


int is_binary_op(char * c) {
    switch (c[0]) {
        case '+':
        case '/':
        case '*':
        case '-':
        case '<':
        case '>':
        case '&':
        case '|':
            return 1;
        default:
            return 0;
    }
}

int number(char * token) {
    int hasdot = 1;
    for (int i = 0; i < strlen(token); i++) {
        if (i == 0 && token[i] == '-') continue;
        int dot = token[i] == '.';
        if (!isnumber(token[i]) && ((dot && hasdot) || !dot)) return 0;
        if (dot) hasdot = 1;
    }
    return 1;
}

int string(char * token) {
    for (int i = 0; i < KEYCOUNT; i++) {
        if (strcmp(keywords[i], token) == 0) {
            return 0;
        }
    }
    for (int i = 0; i < strlen(token); i++) {
        if (isalpha(token[i])) return 1;
    }
    return 0;
}

int value(char * token) {
    return string(token) || number(token);
}


int expr(char ** tokens, int count) {

    if (count == 1 && value(tokens[0])) {
        char * args[3] = {"=", tokens[0], "%reg"};
        add_instruction(binary_op, args, 3);
        return 1;
    }
    else if (value(tokens[0]) && is_binary_op(tokens[1]) && value(tokens[2])) {
        char * args[3] = {"=",tokens[0], "%reg"};
        add_instruction(binary_op, args, 3);
        char * args2[3] = {tokens[1], tokens[2], "%reg"};
        add_instruction(binary_op, args2, 3);
        //printf("<is_binary_op>: %s %s, %reg\n", tokens[1], tokens[2]);
        return 1;
    }
    else if (value(tokens[0]) && tokens[1][0] == '=' && tokens[2][0] == '=' && value(tokens[3])) {
        char * args[3] = {"=",tokens[0], "%reg"};
        add_instruction(binary_op, args, 3);
        //printf("<is_assign>: %s, %reg\n", tokens[0]);
        char * args2[3] = {"==", tokens[2], "%reg"};
        add_instruction(binary_op, args2, 3);
       // printf("<is_binary_op>: == %s, %reg\n", tokens[2]);
        return 1;
    }
    return 0;
}

int is_assign(char ** tokens, int count) {
    int lhs_count = 1;
    if (tokens[0]) {

    }
    int strict_assign = tokens[lhs_count][0] == '=';
    int binary_assign = is_binary_op(tokens[lhs_count]) && tokens[lhs_count + 1][0] == '=';
    if (strict_assign) {
        if (!expr(tokens + lhs_count + 1, count - lhs_count - 1)) {
            return 0;
        }
        //printf("<strict_assign>: ");
        //printt(tokens, count);
        char * args[3] = {"=","%reg", tokens[0]};
        add_instruction(binary_op, args, 3);
        //printf("<is_assign>: %reg, %s\n", tokens[0]);
        return 1;
    }
    else if (binary_assign) {
        if (!expr(tokens + lhs_count + 2, count - lhs_count - 2)) {
            return 0;
        }
        char * args[3] = {tokens[lhs_count], "%reg", tokens[0]};
        add_instruction(binary_op, args, 3);
        //printf("<is_binary_op>: %s %reg, %s\n", tokens[lhs_count], tokens[2]);
        //printt(tokens, count);
        return 1;
    }
    return 0;
}

int stmnt(char ** tokens, int count) {
    if (count < 2) {
        return 0;
    }
    else {
        if (strcmp(tokens[0],"goto") == 0) {
            if (count == 2 && string(tokens[1])) {
                char * args[1] = {tokens[1]};
                add_instruction(jump, args, 1);
               // printf("<goto>: %s\n", tokens[1]);
                //printt(tokens, count);
                return 1;
            }
            else if (strcmp(tokens[1],"if") == 0 && tokens[2][0] == '(' && expr(tokens + 3, count - 5) &&  tokens[count - 2][0] == ')' && string(tokens[count - 1])) {
                char * args[2] = {"%reg", tokens[count - 1]};
                add_instruction(jump_if, args, 2);
                //printf("<goto_if>: %reg, %s\n", tokens[count - 1]);
                //printt(tokens, count);
                return 1;
            }
        }
        else if (string(tokens[0])) {
            return is_assign(tokens, count);
        }
        else if (strcmp(tokens[0],"I64") == 0 && string(tokens[1])) {
            char * args[1] = {tokens[1]};
            add_instruction(declare, args, 1);
            //printf("<declare> %s\n", tokens[1]);
            return is_assign(tokens + 1, count - 1);
        }
        else if (count == 2 && strcmp(tokens[0], keywords[3]) == 0) {
            char * args[1] = {tokens[1]};
            add_instruction(print, args, 1);
            return 1;
        }
    }
    return 0;

}




int expressionize(char ** tokens, int count) {
    char * subtokens[count];
    printf("\n\n");
    for (int i = 0, j = 0; i < count; i++, j++) {
        subtokens[j] = tokens[i];
        int colon = subtokens[j][0] == ':';
        printf("%s ", tokens[i]);
        if (subtokens[j][0] == ';' || colon) {
            printf("\n");
            //char ** st = malloc(sizeof(char *) * 10);
            //memcpy(st, subtokens, 10);
            if (colon) {
                if (string(subtokens[0]) && j == 1) {
                    char * args[1] = {subtokens[0]};
                    add_instruction(label, args, 1);
                    //printf("<label>: %s\n", subtokens[0]);
                    //printt(subtokens, j + 1);
                }
                else {
                    printf("Invalid label, labels must contains letters: ");
                    printt(subtokens, j + 1);
                    return 1;
                }
            }
            else {
                int s = stmnt(subtokens,j);
                if (!s) {
                    printf("Invalid statement: ");
                    printt(subtokens, j + 1);
                     return 1;
                }
            }
            //printf("\n");
            j = -1;
            for (int n = 0; n < count; n++) subtokens[n] = "";
        }
        else if (i == count - 1) {
            printf("Statement is incomplete: ");
            printt(subtokens, j + 1);
            return 1;
        }
    }
    return 0;
}