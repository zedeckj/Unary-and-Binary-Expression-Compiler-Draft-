//
// Created by Jordan on 6/22/22.
//

#ifndef COMPILER__TOKENIZER_H
#define COMPILER__TOKENIZER_H

char ** tokenize(char * str_in, int * count);
#endif //COMPILER__TOKENIZER_H
