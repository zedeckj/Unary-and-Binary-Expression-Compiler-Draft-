//
// Created by Jordan on 6/22/22.
//

#include <string.h>
#include <stdlib.h>
#include <printf.h>
#include <assert.h>



int isempty(char c ) {
    return isblank(c) || c == '\0';
}

/*
 * str_in = 1 23 4
 *
 */
/*
char ** tokenize_helper(char ** tokens, char * str_in, int * token_count) {
    assert(str_in[0] != '\n');
    int len = strlen(str_in);
    for (int i = 0; str_in[i] != '\n' && str_in[i] != '\0'; i++) {
        if (isempty(i)) {
            str_in[i] = '\0';
            tokens[*token_count] = str_in;
            str_in += i;
            i = 0;
        }
    }
}



char ** tokenize(char * str_in, int * token_count) {
    assert(*token_count == 0);
    char ** tokens = malloc(strlen(str_in) * sizeof(char *));
    return tokenize_helper(tokens, str_in, token_count);
}


*/



char ** tokenize_helper(char * tokens [], int *count_ptr, char * str_in) {
    //printf("str in:%s\n", str_in);
    //char * new_tokens [count + 1];
    char ** new_tokens = malloc((*count_ptr + 1) * sizeof(char *));
   // printf("tokenize2\n");
    for (int i = 0; i < *count_ptr; i++) {
        new_tokens[i] = tokens[i];
    }
    //printf("1\n");
    int first_space = -1;
    int len = strlen(str_in);
    for (int i = 0; i < len; i++) {
        if (str_in[i] == ' ' || str_in[i] == '\0' || str_in[i] == '\n') {
            first_space = i;
            break;
        }
    }
    //printf("tokenize3\n");
    //printf("first space: %d\n", first_space);
    if (first_space == -1) {
        new_tokens[*count_ptr] = str_in;
        //printf("-1\n");
        //free(tokens);
        *count_ptr += 1;
        return new_tokens;
    }
    //printf("3\n");
   // printf("tokenize4\n");
    new_tokens[*count_ptr] = str_in;
    new_tokens[*count_ptr][first_space] = '\0';
    //printf("4\n");
   // printf("tokenize5\n");
    *count_ptr += 1;
    return tokenize_helper(new_tokens, count_ptr, str_in + first_space + 1);
}

char ** tokenize(char * str_in, int * count) {
    char * tokens = malloc(1);
    //printf("tokenize1\n");
    return tokenize_helper(tokens, count, str_in);
}
