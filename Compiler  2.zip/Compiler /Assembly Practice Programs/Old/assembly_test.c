//
// Created by Jordan on 6/20/22.
//

#include "assembly_test.h"
#include <stdio.h>
#include <stdlib.h>
/*
 * operation src, dst
 */

void addition() {
    FILE * file = fopen("asm.S", "w");
    fprintf(file, "%s",
            "\n"
            ".data\n"
            "\n"
            ".align 16\n"
            ".text\n"
            "\n"
            ".global _main\n"
            "_main:\n"
            "    enter $0, $0\n"
            "    \n"
            "    leave\n"
            "    ret");
    fclose(file);
    system("as asm.S -o test.o");
    system("ld test.o -o test -lSystem");
    system("./test");
}

void hello_world() {
    FILE * file = fopen("asm.S", "w");
    fprintf(file, "%s",
                       "\n"
                       ".data\n"
                       "\n"
                       ".align 16\n"
                       "hello_msg:\n"
                       "    .asciz \"Hello, World!\"\n"
                       "\n"
                       ".text\n"
                       "\n"
                       ".global _main\n"
                       "_main:\n"
                       "    push %rbp\n"
                       "    mov %rsp, %rbp\n"
                       "\n"
                       "    lea hello_msg(%rip), %rdi\n"
                       "    call _puts\n"
                       "\n"
                       "    xor %rax, %rax\n"
                       "    leave\n"
                       "    ret");
    fclose(file);
    system("as asm.S -o test.o");
    system("ld test.o -o test -lSystem");
    system("./test");
}

void test_program() {
    hello_world();
    addition();
}
