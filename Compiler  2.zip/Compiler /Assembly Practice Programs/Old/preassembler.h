//
// Created by Jordan on 6/22/22.
//

#ifndef COMPILER__PREASSEMBLER_H
#define COMPILER__PREASSEMBLER_H

void preassembler(char *);

#endif //COMPILER__PREASSEMBLER_H
