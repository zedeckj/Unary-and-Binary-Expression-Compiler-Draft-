#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "evaluator.h"
#include "assembly_test.h"
#include "preassembler.h"


int and(int a, int b) {
    return a && b;
}

int or(int a, int b) {
    return a || b;
}


int main(int argc, char ** args) {
    //char * exp [] = {"2", "*", "4", "^", "3", "|", "0"};
    //define('|',or,3);
    //eval(exp,7);
    //solve("2 * 4 ^ 2");
    //test_program();
    preassembler("test.j");
    system("as test.s -o test.o");
    system("ld test.o -o test2 -lSystem");
    system("./test2");


}
