//
// Created by Jordan on 6/22/22.
//

#include <stdio.h>
#include <stdlib.h>
#include "tokenizer.h"
#include <string.h>
#include <assert.h>
#include <libc.h>


struct name {
    char * term;
    char * alias;
    char * term2;
    char * alias2;
};

struct string {
    char * string;
    char * name;
};

struct name names[20];
struct string strings[20];
int name_i = 0;
int string_i = 0;

void preprocessor(char * infile) {
    assert(infile[strlen(infile) - 1] == 'j');
    char path[200];
    getcwd(path,200);
    strcat(path,"/");
    strcat(path,infile);
    FILE * read = fopen(path, "r");
    assert(read != NULL);
    char line[100];
    //printf("\ntest1\n");
    while(fgets(line, 50, read)) {
        for (int i = 0; i < 100; i++) {
            if (line[i] == '\n') {
                line[i] = '\0';
            }
        }
        int tcount[1] = {0};
        char ** tokens = tokenize(line, tcount);
        //printf("%s\n",tokens[0]);
        if (strcmp(tokens[0], "#name") == 0 && *tcount > 2) {
            names[name_i].term = malloc(sizeof(char) * 15);
            names[name_i].alias = malloc(sizeof(char) * 15);
            names[name_i].term2 = malloc(sizeof(char) * 15);
            names[name_i].alias2 = malloc(sizeof(char) * 15);
            strcpy(names[name_i].term,tokens[1]);
            strcpy(names[name_i].alias,tokens[2]);
            strcpy(names[name_i].term2,tokens[1]);
            strcpy(names[name_i].alias2,tokens[2]);
            strcat(names[name_i].term2,",");
            strcat(names[name_i].alias2,",");
            printf("t0: %s, t1 %s, t2 %s\n", tokens[0], tokens[1], names[name_i].alias);
            name_i++;
        }
        else if (strcmp(tokens[0], "#string") == 0 && *tcount > 2 && tokens[2][0] == '\"'
        && tokens[2][strlen(tokens[2]) - 1] == '\"') {
            strings[string_i].string = malloc(sizeof(char) * 15);
            strings[string_i].name = malloc(sizeof(char) * 15);
            strcpy(strings[string_i].string, tokens[1]);
            strcpy(strings[string_i].name, tokens[2]);
            string_i++;
        }
        //printf("fgets\n");
    }
    fclose(read);
    printf("formatter done!\n");
}

void formatter(char * infile) {
    assert(infile[strlen(infile) - 1] == 'j');
    char path[200];
    getcwd(path,200);
    strcat(path,"/");
    strcat(path,infile);
    FILE * read = fopen(path, "r");
    assert(read);
    char * outfile = malloc((strlen(infile) + 1) * sizeof(char));
    strcpy(outfile, infile);
    outfile[strlen(outfile) - 1] = 's';
    FILE * write = fopen(outfile, "w");
    assert(write);
    free(outfile);
    fprintf(write, ".data\n\n.align 16\n");
    printf(".data\n\n.align 16\n");
    /*
    for (int i = 0; i < string_i; i++) {
        fprintf(write, "%s:\n\t.asciz %s",strings[i].name, strings[i].string);
    }
    */
    fprintf(write,"%s","\n.text\n\n.global _main\n\n");
    printf("%s","\n.text\n\n.global _main\n");
    char line[50];
    while(fgets(line, 50, read)) {
        int tcount[1];
        tcount[0] = 0;
        //printf("%s",line);
        char ** tokens = tokenize(line, tcount);
        //printf("has %d tokens\n\n", tcount[0]);
        int mallocd = 0;
        char *t0, *t1, *t2;
        printf("tcount:%d\n", tcount[0]);
        for (int i = 0; i < tcount[0]; i++) {
            if (tokens[i+1] && tokens[i+2] && tokens[i+1][0] == '=') {
                printf("= FOUND!\n");
                mallocd = 1;
                t0 = malloc((strlen(tokens[i]) + 1) * sizeof(char));
                t1 = malloc((strlen(tokens[i+1]) + 1) * sizeof(char));
                t2 = malloc((strlen(tokens[i+2]) + 1) * sizeof(char));
                strcpy(t0, tokens[i]);
                strcpy(t1, tokens[i+1]);
                strcpy(t2, tokens[i+2]);
                strcat(t2, ",");
                tokens[i] = "mov";
                tokens[i+1] = t2;
                tokens[i+2] = t0;
            }
            for (int j = 0; j < name_i; j++) {
                if (strcmp(tokens[i], names[j].alias) == 0) {
                    tokens[i] = names[j].term;
                }
                if (strcmp(tokens[i], names[j].alias2) == 0) {
                    tokens[i] = names[j].term2;
                }
            }
            fprintf(write,"%s ", tokens[i]);
            //printf("%s ", tokens[i]);
        }
        if (mallocd) {
            free(t0);
            free(t1);
            free(t2);
        }
        fprintf(write,"\n");
        printf("\n");
    }
    for (int i = 0; i < name_i; i++) {
        free(names[i].alias);
        free(names[i].term);
    }
    for (int i = 0; i < string_i; i++) {
        free(strings[i].name);
        free(strings[i].string);
    }
    fclose(write);

}

void preassembler(char * file) {
    preprocessor(file);
    formatter(file);
}

/*
void toSFile(char * in) {
    FILE * read = fopen(in, "r");
    char * w = in;
    int len = strlen(in);
    assert(in[len-1] == 'j');
    w[len-1] = 's';
    FILE * write = fopen(w, "w");
    char * line = malloc(sizeof(char) * 50);
    while(fgets(line, 50, read)) {
        int *count;
        char ** tokens = tokenize(line, count);

        for (int i = 0; i < *count; i++) {
            if (i == 0) {
                if (strcmp(tokens[i],"#name") == 0) {
                    name(tokens[i+1], tokens[i+2]);
                }
            }

            fprintf(write, "%s", tokens[i]);
        }
        fprintf(write, "\n");
        free(tokens);
    }
    free(line);
    fclose(read);
    fclose(write);
}
 */

