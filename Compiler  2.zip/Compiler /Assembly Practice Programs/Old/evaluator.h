//
// Created by Jordan on 5/18/22.
//

#ifndef COMPILER__EVALUATOR_H
#define COMPILER__EVALUATOR_H

typedef int (*func)(int, int);

int eval(const char * str [], int count);

int solve(const char * str);

void define(char c, func f,int prec);

void delete(char c);



#endif //COMPILER__EVALUATOR_H
