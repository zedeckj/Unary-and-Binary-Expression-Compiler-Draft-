//
// Created by Jordan on 6/20/22.
//

#ifndef COMPILER__ASSEMBLY_TEST_H
#define COMPILER__ASSEMBLY_TEST_H
void addition();
void hello_world();
void test_program();
#endif //COMPILER__ASSEMBLY_TEST_H
