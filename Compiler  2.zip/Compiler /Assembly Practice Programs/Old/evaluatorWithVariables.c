//
// Created by Jordan on 5/18/22.
//

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "evaluator.h"
#define OPLEN 10

int inited = 0;
int custom = 6;


typedef int (*func)(int, int);

struct variable_symbol_map {
    char symbol;
    int index;
    struct variable_symbol_map *next;
} * variable_symbol_map;

struct variable_list {
    int value;
    struct variable_list *next;
} * variables;

typedef struct operation_s {
    char symbol;
    func function;
    int precedence;
} operation;

typedef struct term_s {
    union {
        operation op;
        int num;
    } object;
    //0- op, 1- num
    int type;
} term;

operation oplist[OPLEN];

int zero(int a, int b) {
    return 0;
}

int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}

int mlt(int a, int b) {
    return a * b;
}

int dvd(int a, int b) {
    return a / b;
}

int xpo(int a, int b) {
    if (b <= 0) return 1;
    if (b == 1) return a;
    return a * xpo(a, b - 1);
}

int assign_helper(int index, int value, struct variable_list * list){
    if (index == 0) {
        list->value = value;
        return 1;
    }
    if (!list->next) {
        list->next = malloc(sizeof(struct variable_list));
    }
    return assign_helper(index - 1, value, list->next);

}

int assign(int a, int b) {
    assign_helper(a,b,variables);
}

void init() {
    oplist[0].symbol = 'z';
    oplist[0].function = zero;
    oplist[0].precedence = 0;
    oplist[1].symbol = '+';
    oplist[1].function = add;
    oplist[1].precedence = 3;
    oplist[2].symbol = '-';
    oplist[2].function = sub;
    oplist[2].precedence = 3;
    oplist[3].symbol = '*';
    oplist[3].function = mlt;
    oplist[3].precedence = 2;
    oplist[4].symbol = '/';
    oplist[4].function = dvd;
    oplist[4].precedence = 2;
    oplist[5].symbol = '^';
    oplist[5].function = xpo;
    oplist[5].precedence = 1;
}

void define(char symbol, func function, int precedence) {
    oplist[custom].symbol = symbol;
    oplist[custom].precedence = precedence;
    oplist[custom].function = function;
}


void print_terms(term terms[], int count);
//'2', '+', '2', '*', '3'
//Assumes valid syntax
int solve_terms(term terms [], int count, int prec) {
    //printf("solve ");
    //print_terms(terms, count);
    //printf(" with prec %d\n", prec);
    if (count == 1) return terms[0].object.num;;
    term new_terms[count];
    int j, i;
    int found = 0;
    for (j = 0, i = 0; i < count; i++, j++) {
        //printf("i:%d\n", i);
        if (!found && terms[i].type == 0 && terms[i].object.op.precedence == prec) {
            j--;
            //printf("op %c has prec %d\n", terms[i].object.op.symbol, terms[i].object.op.precedence);
            new_terms[j].object.num = terms[i].object.op.function(terms[i-1].object.num, terms[i+1].object.num);
            new_terms[j].type = 1;
           // printf("new_terms[%d] = %d\n", j, new_terms[j].object.num);
            //print_terms(new_terms, j + 1);
            i += 1;
            found = 1;
        }
        else {
            //printf("new_terms[%d] = terms[%d] = %d\n", j, i, terms[i].object.num);
            new_terms[j] = terms[i];
        }
    }
    if (found) {
        return solve_terms(new_terms, j, (prec + 1) % 4);
    }
    else {
        return solve_terms(terms, count, (prec + 1) % 4);
    }
}

/*
int stoi(char * str) {
    int out = 0;
    int len = strlen(str);
    int j = 0;
    for (int i = len - 1; i >= 0; i--) {
        printf("str[i] == %c\n", str[i]);
        out += atoi(str[i]) * (xpo(10,j));
        printf("atoi(%c)\n", str[i]);
        j++;
    }
    printf("%s\n", str);
    return out;
}
 */

void print_terms(term terms[], int count) {
    for (int i = 0; i < count; i++) {
        if (terms[i].type == 0) {
           printf("%c ",terms[i].object.op.symbol);

        }
        else {
            printf("%d ", terms[i].object.num);
        }
    }
    //printf("\n");
}



int tokenize(const char * tokens [], int count, const char * str_in) {
    //printf("str in:%s\n", str_in);
    char * new_tokens [count + 1];
    for (int i = 0; i < count; i++) {
        new_tokens[i] = tokens[i];
    }
    //printf("1\n");
    int first_space = -1;
    int len = strlen(str_in);
    for (int i = 0; i < len; i++) {
        if (str_in[i] == ' ') {
            first_space = i;
            break;
        }
    }
    //printf("first space: %d\n", first_space);
    if (first_space == -1) {
        new_tokens[count] = str_in;
        //printf("first token: %s", new_tokens[0]);
        int out = eval(new_tokens, count + 1);
        for (int i = 0; i < count; i++) {
            free(new_tokens[i]);
        }
        return out;
    }
    //printf("3\n");
    new_tokens[count] = malloc(sizeof(char) * first_space + 1);
    strncpy(new_tokens[count], str_in, first_space + 1);
    //printf("4\n");
    return tokenize(new_tokens, count + 1, str_in + first_space + 1);
}


int solve(const char * str) {
    char * tokens [0];
    return tokenize(tokens, 0, str);
}


int eval(const char * strs [], int count) {
    if (!inited) init();
    term terms[count];
    for (int i = 0; i < count; i++) {
        // printf("%d\n", i);
        int op = 0;
        for (int j = 0; j < OPLEN; j++) {
            // printf("checking symbol %c\n", oplist[j].symbol);
            if (strs[i][0] == oplist[j].symbol) {
                terms[i].type = 0;
                terms[i].object.op = oplist[j];
                op = 1;
                break;
            }
        }
        if (!op) {
            // printf("not an op\n");
            terms[i].type = 1;
            terms[i].object.num = atoi(strs[i]);
        }
    }
    // printf("termated\n");
    // print_terms(terms,count);
    print_terms(terms, count);
    int out = solve_terms(terms,count, 0);
    printf("= %d", out);
    return out;
}













