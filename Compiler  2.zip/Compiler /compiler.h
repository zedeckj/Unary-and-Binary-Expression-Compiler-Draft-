//
// Created by Jordan on 6/29/22.
//

#ifndef COMPILER__COMPILER_H
#define COMPILER__COMPILER_H

void compile();

#endif //COMPILER__COMPILER_H


