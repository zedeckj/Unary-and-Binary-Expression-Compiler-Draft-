//
// Created by Jordan on 6/27/22.
//

#ifndef COMPILER__EXPRESSIONIZER_H
#define COMPILER__EXPRESSIONIZER_H

enum type{declare, jump_if, jump, binary_op, label, print};

struct instruction {
    enum type type;
    char **args;
    int argc;
};

struct instruction * instructs;

extern int idcount;
extern int labels;
extern int ii;

int expressionize(char ** tokens, int count);

int number(char * token);

#endif //COMPILER__EXPRESSIONIZER_H
