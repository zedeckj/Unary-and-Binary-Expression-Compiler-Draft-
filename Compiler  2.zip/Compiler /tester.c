//
// Created by Jordan on 6/23/22.
//

#include "tokenizer.h"
#include "expressionizer.h"
#include "compiler.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int main() {
    int *count = malloc(sizeof(int *));
    *count = 0;
    char *str = malloc(sizeof(char) * 200);
    //strcpy(str,"test string this is a test. 20+2.1= 4. 2More tes3ts with random 3 1 shit what was that?..");
    strcpy(str, "I64 var = -1; puts var; var += 2; puts var; var *= 0; puts var; var = 7 - var; puts var;");
    char **tokens = tokenize(str, count);
    int error = expressionize(tokens, *count);
    if (!error) {
        compile();
        printf("result is: \n");
        system("as asm.s -o test.o");
        system("ld test.o -o exec -lSystem");
        system("./exec");
    }
    free(tokens);
}